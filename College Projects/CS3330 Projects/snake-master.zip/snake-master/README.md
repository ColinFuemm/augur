# Snake
A simple snake game in javafx

## https://www.youtube.com/watch?v=VmChebZcb2U

![Snake](preview.jpg)
