/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cjffqwmoviesf21;

/**
 *
 * @author Colin
 */
public enum Genre {
    ACTION, ANIMATION, COMEDY, DRAMA, FANTASY, HORROR, ROMANCE, SCI_FI,
    SUSPENSE, WESTERN, KIDS, UNKNOWN //modeled after Petstore's Gender.java
}
