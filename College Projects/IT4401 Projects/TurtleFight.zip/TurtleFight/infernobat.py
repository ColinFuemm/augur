import random
from turtle import Turtle

def left_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "gray"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        left_lines(turtle, angle, length, lines)

def right_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "gray"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        right_lines(turtle, angle, length, lines)

def circle_town(turtle, angle, radius, lines):
    colors = ["orange"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.circle(radius)
    lines = lines - 1
    if (lines > 0):
        circle_town(turtle, angle, radius, lines)

def main():
    ANIMATION_SPEED = 100
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 0, 1) #turn left to face up
    right_lines(leonardo, 6, 6.28, 19) #left wing top circle
    circle_town(leonardo, 0, 5, 1)#exe
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1) #spikey crown
    circle_town(leonardo, 0, 5, 1)#eye
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 0, 1)
    right_lines(leonardo, 6, 6.28, 19) #right wing
    right_lines(leonardo, 136, 40, 1)
    left_lines(leonardo, 44, 95, 1) #underbelly
    right_lines(leonardo, 86, 95, 1)
    left_lines(leonardo, 36, 40, 1) #connect-ish

main()
