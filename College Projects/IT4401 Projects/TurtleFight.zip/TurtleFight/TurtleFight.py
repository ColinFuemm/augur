import random
import pickle
from Classes import User 
from Classes import Enemy
from turtle import Turtle

enemyList = [ Enemy("Test Dummy", 15, 100, 10, 0, 1),
              Enemy("Delicious Feesh", 30, 10, 9, 12, -1),
              Enemy("Inferno Bat", 50, 12, 8, 30, 3) ]

def left_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        left_lines(turtle, angle, length, lines)

def right_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        right_lines(turtle, angle, length, lines)

def circle_town(turtle, angle, radius, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.circle(radius)
    lines = lines - 1
    if (lines > 0):
        circle_town(turtle, angle, radius, lines)

def test_dummy():
    ANIMATION_SPEED = 10
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 0, 100, 1) #//right
    left_lines(leonardo, 90, 10, 1) #//up
    left_lines(leonardo, 90, 100, 1)# //left
    right_lines(leonardo, 90, 300, 1) #// uuuuuup
    right_lines(leonardo, 180, 100, 1)# //doown
    left_lines(leonardo, 90, 80, 1)# //left
    left_lines(leonardo, 180, 160, 1) #//right ight
    left_lines(leonardo, 180, 80, 1) #//back left
    right_lines(leonardo, 90, 200, 1)# //big down
    right_lines(leonardo, 90, 100, 1) #//left
    left_lines(leonardo, 90, 10, 1) #//down
    left_lines(leonardo, 90, 100, 1) #back!

def feesh():
    ANIMATION_SPEED = 150
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 150, 1) #across to top of head
    #right_lines(leonardo, 45, 1, 1) #begin cirle
    right_lines(leonardo, 6, 6, 15) #begin cirle
    circle_town(leonardo, 180, 10, 1)
    circle_town(leonardo, 0, 3, 1) #eye and sparkle
    right_lines(leonardo, 180, 0, 1)
    right_lines(leonardo, 6, 6, 15)
    right_lines(leonardo, 40, 20, 1) #mouth and turning around
    right_lines(leonardo, 180, 20, 1)
    right_lines(leonardo, 140, 0, 1)
    right_lines(leonardo, 6, 6, 15) #complete circle
    right_lines(leonardo, 0, 150, 1)

def inferno_bat():
    ANIMATION_SPEED = 100
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 0, 1) #turn left to face up
    right_lines(leonardo, 6, 6.28, 19) #left wing top circle
    circle_town(leonardo, 0, 5, 1)#exe
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1) #spikey crown
    circle_town(leonardo, 0, 5, 1)#eye
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 0, 1)
    right_lines(leonardo, 6, 6.28, 19) #right wing
    right_lines(leonardo, 136, 40, 1)
    left_lines(leonardo, 44, 95, 1) #underbelly
    right_lines(leonardo, 86, 95, 1)
    left_lines(leonardo, 36, 40, 1) #connect-ish
    

def drawturt():
    ANIMATION_SPEED = 10
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 180, 40, 1) #tail
    left_lines(leonardo, 90, 20, 1) #first leg
    left_lines(leonardo, 180, 20, 1)
    left_lines(leonardo, 90, 10, 1)
    left_lines(leonardo, 90, 20, 1) #second leg
    left_lines(leonardo, 180, 20, 1)
    left_lines(leonardo, 90, 65, 1)
    left_lines(leonardo, 90, 20, 1) #third leg
    left_lines(leonardo, 180, 20, 1)
    left_lines(leonardo, 90, 10, 1)
    left_lines(leonardo, 90, 20, 1) #fourth leg
    left_lines(leonardo, 180, 20, 1) 
    left_lines(leonardo, 90, 55, 1)
    right_lines(leonardo, 70, 0, 1)
    right_lines(leonardo, 6, 1.5, 35) #head
    left_lines(leonardo, 100, 2, 1)
    left_lines(leonardo, 90, 1, 1)
    right_lines(leonardo, 6, 7, 30) #shell
    
    
drawList = [ test_dummy, feesh, inferno_bat, test_dummy, test_dummy ]
    
def cpuPlay(): #to do
    n = 5
    return n
def userPlay(User):
    while(True):  
        print("1 Attack")
        print("2 Magic")
        print("3 Heal")
        string = input("What will you do?")
        if string == "1":
            return 0
        elif string == "2":
            if(User.getMP() <= 0):
                print("Out of MP!")
                return userPlay(User)
            print("1 Fire Magic")
            print("2 Plant Magic")
            print("3 Water Magic")
            magic = input("What will you cast?")
            if magic == "1":
                User.setMP(User.getMP() -1)
                return 1
            elif magic == "2":
                User.setMP(User.getMP() -1)
                return 2
            elif magic == "3":
                User.setMP(User.getMP() -1)
                return 3
            else:
                print("Oh No! Your Value! It Isn't 1 2 or 3!")
                return userPlay(User)
        elif string == "3":
            return 4
        else:
            print("Oh No! Your Value! It Isn't 1 2 or 3!")
            return userPlay(User)
def print_stats(User):
    name = User.get_name()
    win = User.get_wins()
    loss = User.get_losses()
    print(name + "'s Progress:")
    print("Level ", win + 1, "/4")
    print("Lives: ", 3 - loss)
    
def reprompt(User):
    print("\nWhat would you like to do?")
    print("1 Play Again!")
    print("2 View Statistics")
    print("3 Exit Program")
    string = input("Enter Choice: ")
    return string

def RcokPpaercSssiors(User):
    progress = User.get_wins()
    if progress >= 3:
        return 99
    Enemy = enemyList[progress]
    EnemyATB = 0
    AllyATB = 0
    AllymaxHP = User.get_MaxHP()
    AllyHP = User.get_HP()
    EnemymaxHP = Enemy.get_MaxHP()
    EnemyHP = EnemymaxHP
    print("\nRound: ", 1+progress)
    print("Opponent: ", Enemy.get_name())
    drawList[progress]()
    print("Lives Left: ", 3 - User.get_losses())
    
    while( AllyHP > 0 and EnemyHP > 0 ):
        AllyATB += User.get_Spd()
        if(AllyATB >= 100):
            AllyATB -= 100
            print("\nEnemy: ", EnemyHP, "/", EnemymaxHP, "HP")
            print("You: ", AllyHP, "/100HP ", User.getMP(), "/10MP")
            dmg = User.get_Atk()
            you = userPlay(User)
            if you == 0:
                dmg = dmg - Enemy.get_Def()
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 1:
                if (Enemy.get_Weakness() == 1) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Enemy.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 2:
                if (Enemy.get_Weakness() == 2) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Enemy.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 3:
                if (Enemy.get_Weakness() == 3) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Enemy.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 4:
                AllyHP += 25
                User.setMP(User.getMP() -1) 
                print("You have healed for 15 hitpoints.")
    
        EnemyATB += Enemy.get_Spd()
        if(EnemyATB >= 100):
            EnemyATB -= 100
            them = Enemy.get_Atk()
            AllyHP = AllyHP - them
            print(Enemy.get_name(), " attacked for ", them, " damage!")
    
    if( EnemyHP <= 0 ):
        print("Congratulations! You have defeated ", Enemy.get_name())
        User.Victory()
        User.set_HP(AllyHP)
        return
    if( AllyHP <= 0 ):
        print("You have fallen to ", Enemy.get_name(), ".")
        User.Defeat()
        if User.get_losses() >= 3:
            print("Out of Lives! Better Luck Next Time D:")
            return -1
        else:
            AllyHP = AllymaxHP
            User.setMP(10)
            print("Opponent: ", Enemy.get_name())
            print("Lives Left: ", 3 - User.get_losses())
    #defeat increases losses, three losses resets you to the start
        
def TurtleFight(User):  #final function: its boss fight time########################################################final function: its boss fight time
    progress = User.get_wins()
    hp = 70 + 10*progress
    atk = 7 + 1*progress
    defense = 5
    spd = 12
    weak = -1
    Boss = Enemy("Turtle", hp, atk, defense, spd, weak)
    EnemyATB = 0
    AllyATB = 0
    AllymaxHP = User.get_MaxHP()
    AllyHP = User.get_HP()
    EnemymaxHP = Boss.get_MaxHP()
    EnemyHP = EnemymaxHP
    print("\nRound: ", 1+progress)
    print("Opponent: ", Boss.get_name())
    drawturt()
    print("Lives Left: ", 3 - User.get_losses())
    turtlecharge = 0
    uses = 0
    
    while( AllyHP > 0 and EnemyHP > 0 ):
        AllyATB += User.get_Spd()
        if(AllyATB >= 100):
            AllyATB -= 100
            print("\nTurtle: ", EnemyHP, "/", EnemymaxHP, "HP ", turtlecharge, "/3 charge")
            print("You: ", AllyHP, "/100HP ", User.getMP(), "/10MP")
            dmg = User.get_Atk()
            you = userPlay(User)
            if you == 0:
                dmg = dmg - Boss.get_Def()
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 1:
                if (Boss.get_Weakness() == 1) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Boss.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 2:
                if (Boss.get_Weakness() == 2) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Boss.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 3:
                if (Boss.get_Weakness() == 3) :
                    dmg = 2*dmg
                    print("Super Effective!")
                dmg = dmg - Boss.get_Def() + 3
                EnemyHP -= dmg
                print("You dealt ", dmg, " damage!")
            elif you == 4:
                AllyHP += 20 + 2*progress
                User.setMP(User.getMP() -1) 
                print("You have healed for ", 20 + 2*progress ," hitpoints.")
    
        EnemyATB += Boss.get_Spd()
        if(EnemyATB >= 100):
            EnemyATB -= 100
            turtlecharge = turtlecharge + 1
            if turtlecharge == 4:
                turtlecharge = 0
                uses = uses +1
                them = (Boss.get_Atk()+uses)*3
                AllyHP = AllyHP - them
                if uses == 1:
                    print("Turtle fires their green laser for ", them , " damage!")
                    print("You see plants and moss begin to grow on the shell.")
                    weak = 1
                    Boss = Enemy("Turtle", EnemyHP + 15, atk, defense, spd, weak)
                elif uses == 2:
                    print("Turtle fires their blue laser for ", them , " damage!")
                    print("Water splashes at your feet, making your feet feel sluggish.")
                    weak = 2
                    Boss = Enemy("Turtle", EnemyHP, atk, defense, spd + 10, weak)
                elif uses == 3:
                    uses = 0
                    print("Turtle fires their red laser for ", them + 6 , " damage!")
                    print("The Turtle seems enraged, and smoke billows from their mouth.")
                    weak = 3
                    Boss = Enemy("Turtle", EnemyHP, atk + 2, defense, spd, weak)
            else:
                if turtlecharge ==3:
                    print("Turtle is charging up!")
                    continue
                them = Boss.get_Atk()
                AllyHP = AllyHP - them
                print(Boss.get_name(), " attacked for ", them, " damage!")
    
    if( EnemyHP <= 0 ):
        print("Congratulations! You have defeated ", Boss.get_name())
        User.Victory()
        User.set_HP(AllyHP)
        return
    if( AllyHP <= 0 ):
        print("You have fallen to ", Boss.get_name(), ".")
        User.Defeat()
        if User.get_losses() >= 3:
            print("Out of Lives! Better Luck Next Time D:")
            return -1
        else:
            AllyHP = AllymaxHP
            User.setMP(10)
    #defeat increases losses, three losses resets you to the start  
    
def prompt_user():
    print("Welcome to Turtle Fight RPG!")
    print("1 New Game")
    print("2 Load Game")
    print("3 Exit Program")
    string = input("What would you like to do? ")
    return string
def save_user(filename, user):
    users = [user]
    try:
        output_file = open(filename, "wb")
        pickle.dump(users, output_file)
        output_file.close()
    except Exception as e:
        print("Sorry " + user.get_name() + ", your game could not be saved.")
        print(e)
def new_user(name):
    return User(name, 0, 0, 100, 15, 15)
def load_user(name):
    filename = name + ".rps"
    try:
        user_file = open(filename, "rb")
        users = pickle.load(user_file)
        user = users[0]
        user_file.close()
    except:
        user = User(name, 0, 0, 100, 15, 15)
    return user
def get_name():
    name = input("What is your name? ")
    return name

def main():
    string = prompt_user()
    if string == "1":
            name = get_name()
            User = new_user(name)
            RcokPpaercSssiors(User)
    elif string == "2":
            name = get_name()
            User = load_user(name)
            if RcokPpaercSssiors(User) == -1:
                User = new_user(name)
                save_user(name + ".rps", User)
                print("---progress has been reset---")
            elif RcokPpaercSssiors(User) == 99:
                if TurtleFight(User) == -1:
                User = new_user(name)
                save_user(name + ".rps", User)
                print("---progress has been reset---")
    elif string == "3":
            return
    else:
        print("Oh no! Your Value! It Isn't 1 2 or 3!")
    while (True):
        string = reprompt(User)
        if string == "1":
            if RcokPpaercSssiors(User) == -1:
                User = new_user(name)
                save_user(name + ".rps", User)
                print("---progress has been reset---")
            elif RcokPpaercSssiors(User) == 99:
                if TurtleFight(User) == -1:
                User = new_user(name)
                save_user(name + ".rps", User)
                print("---progress has been reset---")
        elif string == "2":
            print_stats(User)
        elif string == "3":
            save_user(name + ".rps", User)
            print(name + ", your game has been saved")
            break
        else:
            print("Oh no! Your Value! It Isn't 1 2 or 3!")
main()
