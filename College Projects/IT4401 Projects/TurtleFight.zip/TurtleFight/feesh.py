import random
from turtle import Turtle

def left_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "gray"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        left_lines(turtle, angle, length, lines)

def right_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "gray"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        right_lines(turtle, angle, length, lines)

def circle_town(turtle, angle, radius, lines):
    colors = ["orange"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.circle(radius)
    lines = lines - 1
    if (lines > 0):
        circle_town(turtle, angle, radius, lines)

def main():
    ANIMATION_SPEED = 150
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 150, 1) #across to top of head
    #right_lines(leonardo, 45, 1, 1) #begin cirle
    right_lines(leonardo, 6, 6, 15) #begin cirle
    circle_town(leonardo, 180, 10, 1)
    circle_town(leonardo, 0, 3, 1) #eye and sparkle
    right_lines(leonardo, 180, 0, 1)
    right_lines(leonardo, 6, 6, 15)
    right_lines(leonardo, 40, 20, 1) #mouth and turning around
    right_lines(leonardo, 180, 20, 1)
    right_lines(leonardo, 140, 0, 1)
    right_lines(leonardo, 6, 6, 15) #complete circle
    right_lines(leonardo, 0, 150, 1)
    

main()
