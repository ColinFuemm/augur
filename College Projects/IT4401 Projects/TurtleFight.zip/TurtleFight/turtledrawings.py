import random
from turtle import Turtle

def left_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        left_lines(turtle, angle, length, lines)

def right_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        right_lines(turtle, angle, length, lines)

def circle_town(turtle, angle, radius, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.circle(radius)
    lines = lines - 1
    if (lines > 0):
        circle_town(turtle, angle, radius, lines)

def test_dummy():
    ANIMATION_SPEED = 10
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 0, 100, 1) #//right
    left_lines(leonardo, 90, 10, 1) #//up
    left_lines(leonardo, 90, 100, 1)# //left
    right_lines(leonardo, 90, 300, 1) #// uuuuuup
    right_lines(leonardo, 180, 100, 1)# //doown
    left_lines(leonardo, 90, 80, 1)# //left
    left_lines(leonardo, 180, 160, 1) #//right ight
    left_lines(leonardo, 180, 80, 1) #//back left
    right_lines(leonardo, 90, 200, 1)# //big down
    right_lines(leonardo, 90, 100, 1) #//left
    left_lines(leonardo, 90, 10, 1) #//down
    left_lines(leonardo, 90, 100, 1) #back!

def feesh():
    ANIMATION_SPEED = 150
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 150, 1) #across to top of head
    #right_lines(leonardo, 45, 1, 1) #begin cirle
    right_lines(leonardo, 6, 6, 15) #begin cirle
    circle_town(leonardo, 180, 10, 1)
    circle_town(leonardo, 0, 3, 1) #eye and sparkle
    right_lines(leonardo, 180, 0, 1)
    right_lines(leonardo, 6, 6, 15)
    right_lines(leonardo, 40, 20, 1) #mouth and turning around
    right_lines(leonardo, 180, 20, 1)
    right_lines(leonardo, 140, 0, 1)
    right_lines(leonardo, 6, 6, 15) #complete circle
    right_lines(leonardo, 0, 150, 1)

def inferno_bat():
    ANIMATION_SPEED = 100
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    left_lines(leonardo, 45, 0, 1) #turn left to face up
    right_lines(leonardo, 6, 6.28, 19) #left wing top circle
    circle_town(leonardo, 0, 5, 1)#exe
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1) #spikey crown
    circle_town(leonardo, 0, 5, 1)#eye
    left_lines(leonardo, 135, 10, 1)
    right_lines(leonardo, 135, 10, 1)
    left_lines(leonardo, 135, 0, 1)
    right_lines(leonardo, 6, 6.28, 19) #right wing
    right_lines(leonardo, 136, 40, 1)
    left_lines(leonardo, 44, 95, 1) #underbelly
    right_lines(leonardo, 86, 95, 1)
    left_lines(leonardo, 36, 40, 1) #connect-ish

