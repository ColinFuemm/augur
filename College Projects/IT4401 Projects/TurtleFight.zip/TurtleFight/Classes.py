class User:
    def __init__(self, name, win, loss, HP, Atk, Spd):
        self.__name = name
        self.__win = win
        self.__loss = loss
        self.__HP = HP
        self.__MP = 10
        self.__tempMP = self.__MP
        self.__tempHP = HP
        self.__Atk = Atk
        self.__Spd = Spd

    def get_name(self):
        return self.__name
    def get_wins(self):
        return self.__win
    def get_losses(self):
        return self.__loss
    def get_MaxHP(self):
        return self.__HP
    def get_HP(self):
        return self.__tempHP
    def set_HP(self, HP):
        self.__tempHP = HP
    def get_Atk(self):
        return self.__Atk
    def get_Spd(self):
        return self.__Spd
    def getMP(self):
        return self.__tempMP
    def setMP(self, MP):
        self.__tempMP = MP
    def Victory(self):
        self.__win = self.__win+1
    def Defeat(self):
        self.__loss = self.__loss+1
        self.__tempHP = self.__HP

class Enemy:
    def __init__(self, name, HP, Atk, Def, Spd, Weakness):
        self.__name = name
        self.__HP = HP
        self.__tempHP = HP
        self.__Atk = Atk
        self.__Def = Def
        self.__Spd = Spd
        self.__Weakness = Weakness

    def get_name(self):
        return self.__name
    def get_MaxHP(self):
        return self.__HP
    def get_HP(self):
        return self.__tempHP
    def set_HP(self, HP):
        self.__tempHP = HP
    def get_Atk(self):
        return self.__Atk
    def get_Def(self):
        return self.__Def
    def get_Spd(self):
        return self.__Spd
    def get_Weakness(self):
        return self.__Weakness
    
