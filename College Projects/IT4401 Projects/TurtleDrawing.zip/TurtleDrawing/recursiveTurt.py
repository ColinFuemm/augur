import random
from turtle import Turtle

def recursive_lines(turtle, angle, length, lines):
    colors = ["red", "orange", "brown", "green", "blue", "purple"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.left(angle)
    turtle.forward(length)
    lines = lines - 1
    if (lines > 0):
        recursive_lines(turtle, angle, length, lines)

def main():
    ANIMATION_SPEED = 5
    leonardo = Turtle()
    leonardo.speed(ANIMATION_SPEED)
    recursive_lines(leonardo, 216, 300, 5)
    recursive_lines(leonardo, 144, 300, 5)
    recursive_lines(leonardo, 90, 177, 1)
    recursive_lines(leonardo, 90, 300, 1)
    recursive_lines(leonardo, 90, 354, 1)
    recursive_lines(leonardo, 90, 300, 1)
    recursive_lines(leonardo, 90, 177, 1)
    

main()
