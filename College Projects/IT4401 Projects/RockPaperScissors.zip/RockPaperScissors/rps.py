import random
import pickle

class User:
    def __init__(self, name, win, loss, tie):
        self.__name = name
        self.__win = win
        self.__loss = loss
        self.__tie = tie

    def get_name(self):
        return self.__name
    def get_wins(self):
        return self.__win
    def get_losses(self):
        return self.__loss
    def get_ties(self):
        return self.__tie
    def Victory(self):
        self.__win = self.__win+1
    def Defeat(self):
        self.__loss = self.__loss+1
    def Tie(self):
        self.__tie = self.__tie+1
    
def cpuPlay():
    n = random.randrange(1, 4)
    if n == 1:
        print("Rock!")
    elif n == 2:
        print("Paper!")
    elif n == 3:
        print("Scissors!")
    return n
def userPlay():
    while(True):  
        print("1 Rock")
        print("2 Paper")
        print("3 Scissors")
        string = input("What will you play?!?")
        if string == "1":
            return int(string)
        elif string == "2":
            return int(string)
        elif string == "3":
            return int(string)
        else:
            print("Oh No! Your Value! It Isn't 1 2 or 3!")
def print_stats(User):
    name = User.get_name()
    win = User.get_wins()
    loss = User.get_losses()
    tie = User.get_ties()
    print(name + "'s Statistics:")
    print("Wins: ", win)
    print("Losses: ", loss)
    print("Ties: ", tie)
    if(loss == 0):
        print("Win/Loss Ratio: ", win/1.00)
        return
    print("Win/Loss Ratio: ", win/loss)
    
def reprompt(User):
    print("\nWhat would you like to do?")
    print("1 Play Again!")
    print("2 View Statistics")
    print("3 Exit Program")
    string = input("Enter Choice: ")
    return string

def RcokPpaercSssiors(User):
    print("\nRound: ", 1+User.get_wins()+User.get_losses()+User.get_ties())
    you = userPlay()
    them = cpuPlay()
    if(you == them):
        print("Aha. So a tie it is. I guess great minds think alike!")
        User.Tie()
    elif(you == 2 and them == 1):
        print("Wait.. my rock, where did it go? DId you,,, turn it INTO PAPER?!?")
        print("Victory!")
        User.Victory()
    elif(you == 3 and them == 2):
        print("Cut my paper to pieces, but just know it could've been made into a beautiful swan one day.")
        print("Victory!")
        User.Victory()
    elif(you == 1 and them == 3):
        print("ooo look at me I can hit things with a rock im so advanced my brain so big pffffffft")
        print("Victory!")
        User.Victory()
    elif(you == 1 and them == 2):
        print("Now watch as I make this rock... DISSAPEAR!")
        print("Defeat!")
        User.Defeat()
    elif(you == 2 and them == 3):
        print("Haha, beating you is so much better than origami")
        print("Defeat!")
        User.Defeat()
    elif(you == 3 and them == 1):
        print("hell YEAH IMMA SMASH THOSE DUMB SCISSORS RAAAAHAHAHa")
        print("Defeat!")
        User.Defeat()
def prompt_user():
    print("Welcome to my Rock Paper Scissors Game!")
    print("1 New Game")
    print("2 Load Game")
    print("3 Exit Program")
    string = input("What would you like to do? ")
    return string
def save_user(filename, user):
    users = [user]
    try:
        output_file = open(filename, "wb")
        pickle.dump(users, output_file)
        output_file.close()
        print(user.get_name() + ", your game has been saved")
    except Exception as e:
        print("Sorry " + user.get_name() + ", your game could not be saved.")
        print(e)
def new_user(name):
    return User(name, 0, 0, 0)
def load_user(name):
    filename = name + ".rps"
    try:
        user_file = open(filename, "rb")
        users = pickle.load(user_file)
        user = users[0]
        user_file.close()
    except:
        user = User(name, 0, 0, 0)
    return user
def get_name():
    name = input("What is your name? ")
    return name
    
def main():
    string = prompt_user()
    if string == "1":
            name = get_name()
            User = new_user(name)
            RcokPpaercSssiors(User)
    elif string == "2":
            name = get_name()
            User = load_user(name)
            RcokPpaercSssiors(User)
    elif string == "3":
            return
    else:
        print("Oh no! Your Value! It Isn't 1 2 or 3!")
    while (True):
        string = reprompt(User)
        if string == "1":
            RcokPpaercSssiors(User)
        elif string == "2":
            print_stats(User)
        elif string == "3":
            save_user(name + ".rps", User)
            break
        else:
            print("Oh no! Your Value! It Isn't 1 2 or 3!")
            
    
main()
